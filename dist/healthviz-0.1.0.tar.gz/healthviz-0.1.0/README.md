# HealthViz

HealthViz is a Python package for visualizing and analyzing health data. It provides functionality to detect anomalies and generate visualizations such as histograms and scatter plots.

## Features

- Anomaly detection for health-related data (e.g., heart rate).
- Easy-to-use visualizations, including histograms and scatter plots.

## Installation

Install the package using pip:

import pandas as pd
from healthviz import Visualizer

# Sample data
data = pd.DataFrame({'heart_rate': [72, 80, 200, 100]})

# Initialize the visualizer
visualizer = Visualizer(data)

# Create a histogram
visualizer.plot_histogram('heart_rate')
